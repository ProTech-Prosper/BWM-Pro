
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
 <h1 align="center"> PROTECH 𝚳𝐃 </h1>


<a><img src='https://telegra.ph/file/4c2819e618d8946926b82.jpg'/></a>
      
[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&color=blue&lines=𝗔𝗠+TOPU+𝗠𝗗+𝗖𝗥𝗘𝗔𝗧𝗘𝗗+𝗕𝗬+TOPUDMH)](https://git.io/typing-svg)

<a><img src='https://telegra.ph/file/4c2819e618d8946926b82.jpg'/></a>
 
<p align="center"> Introducing TOPU Md, A Simple WhatsApp user BOT, Created by topu Tech.
</p>

  <a href="https://ibb.co/N6NMDtn"><img src="https://telegra.ph/file/4c2819e618d8946926b82.jpg" alt="01" border="0" /></a>                     
<a><img src='https://i.imgur.com/LyHic3i.gif'/>&</a>
 ## 🚀 `Bot Features`
| Feature                          | Description                                             | Available    | Version    |
| ---------------------------------| ------------------------------------------------------- | ------------ | ---------- |
| Multi-Device Support             | Operate the bot on multiple devices simultaneously     | ✅           | 2.0        |
| AI Photo Enhancement             | Enhance photos using advanced AI algorithms            | ✅           | 2.0        |
| Downloader Commands              | Download various types of content from the internet     | ✅           | 2.0        |
| Hidden NSFW Commands             | Access a range of NSFW commands hidden in the bot       | ✅           | 2.0        |
| Logo Commands                    | Generate logos using specialized commands               | ✅           | 2.0        |
| Anime Commands                   | Explore anime-related commands and features              | ✅           | 2.0        |
| Economy Menu                     | Engage in economic activities within the bot            | ✅           | 2.0        |
| Various Games                    | Enjoy a variety of games within the bot                 | ✅           | 2.0        |
| Audio/Video Editor Commands      | Edit audio and video files with bot commands            | ✅           | 2.0        |



<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>


#### SETUP

1. Fork the repo
    <br>
<a href='https://github.com/Toputech/Topu-ai/fork' target="_blank"><img alt='Fork repo' src='https://img.shields.io/badge/Fork Repo-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=black&color=black'/></a>



2. Get Session ID (By pairing code)
   > 
     <a href='https://topu-scan-pair.onrender.com/pair' target="_blank"><img alt='SESSION ID' src='https://img.shields.io/badge/Session_id-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=black&color=black'/></a>


3. Deploy on heroku
    <br>
<a href='https://dashboard.heroku.com/new?template=https://github.com/Toputech/Topu-ai' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/DEPLOY-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=black&color=black'/></a>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

   
## Supported Versions Node Versions to run this bot

Please Use Node Version Higher to Get The Best Performance.

| Version | Supported          |
| ------- | ------------------ |
| 14.x   | :x: |
| 16.x   | ❗                |
| 18.x   | :white_check_mark: |
| 20.x   | ✅                |

## Support 
## Join my channel for updates and get free cc
<a href="https://whatsapp.com/channel/0029VaeRrcnADTOKzivM0S1r" target="_blank">
    <img alt="whatsapp Group" src="https://img.shields.io/badge/ Whatsapp Support Channel -25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
  </a>
</p>


HOW TO REACH THE OWNER? 
 
   
   <a href="https://wa.me+255673750170">
    <img src="https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
  </a>&nbsp;&nbsp;
   <a

    ## Ask any thing
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>



## Makesure you follow my channel for latest updates for TOPU MD bot and free CC
 [`WA CHANNEL`](https://whatsapp.com/channel/0029VaeRrcnADTOKzivM0S1r)



<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
   
   
## Thankyou for choosing TOPU MD bot 


<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

## Contributions


Contributions to *TOPU-MD* are welcome! If you have ideas for new features, improvements, or bug fixes, feel free to open an issue or submit a pull request.

# Security Notice
TOPU Md is safe for your WhatsApp and heroku

## Reporting a Vulnerability


## powered by TOPU MD


## THANKS TO
[france king]

[Venocyber]

[gifted tech]

[king ibrahim]

## License


The *TOPU-MD* is released under the [MIT License](https://opensource.org/licenses/MIT).

Enjoy the diverse features of the *TOPU-MD*  to enhance your Whatsapp more enjoyable
☣Powered by TOPU Tech
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
